package tests;

import org.testng.annotations.Test;
import pages.CreateNewCustomerPage;
import pages.LumaHomePage;
import utils.BaseClass;

public class TestRegistrationProcess extends BaseClass {

    @Test
    public void inspectPage() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver,wait,anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage inspectPage = new CreateNewCustomerPage(driver,wait,anAssert);
        String pageTitle = inspectPage.validatePageTitle();
        String personalInfo = inspectPage.validatePersonalInfo();
        String signInInfo = inspectPage.validateSignInInfo();
        anAssert.assertEquals(pageTitle,"Create New Customer Account");
        anAssert.assertEquals(personalInfo,"Personal Information");
        anAssert.assertEquals(signInInfo,"Sign-in Information");
        anAssert.assertAll();
    }

    @Test
    public void emptyInputs() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("");
        registerAccount.enterLastName("");
        registerAccount.enterEmail("");
        scrollDown1(1000);
        registerAccount.enterPassword("");
        registerAccount.enterConfirmPassword("");
        registerAccount.clickCreateButton();
        String emptyFirstName = registerAccount.validateFirstNameErrorMessage();
        String emptyLastName = registerAccount.validateLastNameErrorMessage();
        String emptyEmail = registerAccount.validateEmailErrorMessage();
        String emptyPassword = registerAccount.validatePasswordErrorMessage();
        String emptyConfirmPassword = registerAccount.validateConfirmPasswordErrorMessage();
        anAssert.assertEquals(emptyFirstName, "This is a required field.");
        anAssert.assertEquals(emptyLastName, "This is a required field.");
        anAssert.assertEquals(emptyEmail, "This is a required field.");
        anAssert.assertEquals(emptyPassword, "This is a required field.");
        anAssert.assertEquals(emptyConfirmPassword, "This is a required field.");
        anAssert.assertAll();
    }

    @Test
    public void invalidEmailFormat() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("Ljubisha");
        registerAccount.enterLastName("Srbinovski");
        registerAccount.enterEmail("ljubomzt#gmail.com");
        scrollDown1(1000);
        registerAccount.enterPassword("#Banana09");
        registerAccount.enterConfirmPassword("#Banana09");
        registerAccount.clickCreateButton();
        String wrongEmailFormat = registerAccount.checkInvalidEmailFormat();
        anAssert.assertEquals(wrongEmailFormat, "Please enter a valid email address (Ex: johndoe@domain.com).");
        anAssert.assertAll();
    }

    @Test
    public void existingEmail() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("Ljubisha");
        registerAccount.enterLastName("Srbinovski");
        registerAccount.enterEmail("ljubomzt@gmail.com");
        scrollDown1(1000);
        registerAccount.enterPassword("#Banana09");
        registerAccount.enterConfirmPassword("#Banana09");
        registerAccount.clickCreateButton();
        String existingEmail = registerAccount.checkAlreadyRegisterEmail();
        anAssert.assertEquals(existingEmail, "There is already an account with this email address. If you are sure that it is your email address, click here to get your password and access your account.");
        anAssert.assertAll();
    }

    @Test
    public void testPasswordCriteria() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("Ljubisha");
        registerAccount.enterLastName("Srbinovski");
        registerAccount.enterEmail("ljubomzt@gmail.com");
        scrollDown1(1000);
        registerAccount.enterPassword("123");
        registerAccount.enterConfirmPassword("#123");
        registerAccount.clickCreateButton();
        String passwordCriteria = registerAccount.verifyPasswordCriteria();
        anAssert.assertEquals(passwordCriteria, "Minimum length of this field must be equal or greater than 8 symbols. Leading and trailing spaces will be ignored.");
        anAssert.assertAll();
    }

    @Test
    public void passwordStrength()  {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("Ljubisha");
        registerAccount.enterLastName("Srbinovski");
        registerAccount.enterEmail("ljubomzt@gmail.com");
        scrollDown1(1000);
        registerAccount.enterPassword("123");
        registerAccount.enterConfirmPassword("123");
        registerAccount.clickCreateButton();
        String passwordStrength = registerAccount.verifyPasswordStrength();
        anAssert.assertEquals(passwordStrength,"Password Strength: Weak");
        anAssert.assertAll();
    }


    @Test
    public void passwordConfirmation() {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        luma.validateCreateAnAccount();
        CreateNewCustomerPage registerAccount = new CreateNewCustomerPage(driver, wait, anAssert);
        registerAccount.enterFirstName("Ljubisha");
        registerAccount.enterLastName("Srbinovski");
        registerAccount.enterEmail("ljubomzt@gmail.com");
        scrollDown1(1000);
        registerAccount.enterPassword("Banana09");
        registerAccount.enterConfirmPassword("Banana999");
        registerAccount.clickCreateButton();
        String confirmPassword = registerAccount.validateConfirmPassword();
        anAssert.assertEquals(confirmPassword, "Please enter the same value again.");
        anAssert.assertAll();
    }

}






