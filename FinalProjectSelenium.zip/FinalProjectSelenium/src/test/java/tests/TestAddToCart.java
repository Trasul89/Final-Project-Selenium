package tests;

import org.testng.annotations.Test;
import pages.CustomerLogIn;
import pages.LumaHomePage;
import pages.ProductPage;
import utils.BaseClass;

public class TestAddToCart extends BaseClass {

    @Test
    public void test() throws InterruptedException {
        driver.get("https://magento.softwaretestingboard.com/");
        LumaHomePage luma = new LumaHomePage(driver,wait,anAssert);
        luma.signIn();

        CustomerLogIn login = new CustomerLogIn(driver,wait,anAssert);
        login.enterEmail("ljubomzt@gmail.com");
        login.enterPassword("#Banana09");

        ProductPage addProduct = new ProductPage(driver,wait,anAssert);
        addProduct.productDropDown();
        addProduct.selectFromDropdown();
        addProduct.clickFilter();
        addProduct.selectFilter();
        scrollDown1(200);
        addProduct.selectFirstProduct();
        String firstProductName = addProduct.validateFirstProductName();
        String firstProductInStock = addProduct.verifyIfInStock();
        addProduct.addFirstProductToCart();
        addProduct.selectAnotherProduct();
        addProduct.selectSecondProduct();
        String secondProductName = addProduct.validateSecondProductName();
        String secondProductInStock = addProduct.verifyIfInStock();
        addProduct.addSecondProductToCart();
        addProduct.enterCart();
        scrollDown1(200);
        String firstProductPrice = addProduct.validateFirstProductPrice();
        String secondProductPrice = addProduct.validateSecondProductPrice();
        String orderTotal = addProduct.orderTotal();
        addProduct.enterShippingAndTax();
        addProduct.setShippingDestination();
        scrollDown1(1000);
        String flatRate = addProduct.flatRate();
        Thread.sleep(2000);
        addProduct.checkout();
        anAssert.assertEquals(firstProductName,"Endeavor Daytrip Backpack");
        anAssert.assertEquals(firstProductInStock,"IN STOCK");
        anAssert.assertEquals(secondProductName,"Driven Backpack");
        anAssert.assertEquals(secondProductInStock,"IN STOCK");
        anAssert.assertEquals(firstProductPrice,"$33.00");
        anAssert.assertEquals(secondProductPrice,"$36.00");
        anAssert.assertEquals(flatRate,"Shipping (Flat Rate - Fixed) $0.00");
        anAssert.assertEquals(orderTotal,"Order Total $69.00");
        anAssert.assertAll();









    }
}
