package tests;

import org.testng.annotations.Test;
import pages.*;
import utils.BaseClass;

public class EndToEndTest extends BaseClass {


    @Test
    public void test() throws InterruptedException {
        driver.get("https://magento.softwaretestingboard.com/");

        LumaHomePage luma = new LumaHomePage(driver, wait, anAssert);
        boolean homePageDropdown = luma.homepageDropdown();
        anAssert.assertTrue(homePageDropdown);
        luma.searchBox("watches");
        luma.searchOptions();
        boolean searchExpected = luma.expectedSearchResults();
        anAssert.assertFalse(searchExpected,"Results are not related with search input");
        luma.backToHomePage();
        String createButtonPresence = luma.createAnAccountButton();
        luma.validateCreateAnAccount();
        anAssert.assertEquals(createButtonPresence,"Create an Account");


        CreateNewCustomerPage create = new CreateNewCustomerPage(driver,wait,anAssert);
        String pageTitlePresence = create.validatePageTitle();
        anAssert.assertEquals(pageTitlePresence,"Create New Customer Account");
        String personalInfoPresence = create.validatePersonalInfo();
        anAssert.assertEquals(personalInfoPresence,"Personal Information");
        boolean firstNamePresence = create.verifyFirstNamePresence();
        anAssert.assertTrue(firstNamePresence,"First Name field is present");
        create.enterFirstName("Ljubisha");
        boolean lastnamePresence = create.verifyLastNamePresence();
        anAssert.assertTrue(lastnamePresence,"Last Name field is present");
        create.enterLastName("Srbinovski");
        boolean emailPresence = create.verifyEmailPresence();
        anAssert.assertTrue(emailPresence,"Email field is present");
        create.enterEmail("srbinovski1989@hotmail.com");
        boolean passwordPresence = create.verifyPasswordPresence();
        anAssert.assertTrue(passwordPresence,"Password field is present");
        create.enterPassword("#Banana09");
        boolean confirmPasswordPresence = create.verifyConfirmPasswordPresence();
        anAssert.assertTrue(confirmPasswordPresence,"Confirm Password field is present");
        create.enterConfirmPassword("#Banana09");
        create.clickCreateButton();

        MyAccountPage accountPage = new MyAccountPage(driver,wait,anAssert);
        String registrationValidationMessage = accountPage.registrationValidation();
        anAssert.assertEquals(registrationValidationMessage,"Thank you for registering with Main Website Store.");
        String contactInfoValidation = accountPage.verifyContactInfo();
        anAssert.assertEquals(contactInfoValidation,"Ljubisha Srbinovski\n" +
                "srbinovski1989@hotmail.com");
        accountPage.editAddress();
        accountPage.enterTelephone("072443770");
        accountPage.enterAddress("ul.Dimitar Gushtanov 34/b");
        accountPage.enterCity("Skopje");
        accountPage.setCountry();
        accountPage.enterState("Skopje");
        accountPage.setZipCode("1000");
        accountPage.saveAddress();
        accountPage.validateHomePageLogo();
        luma.dropDown();


        FitnessEquipmentPage equipment = new FitnessEquipmentPage(driver,wait,anAssert);
        equipment.selectCategory();
        equipment.selectExercise();
        equipment.selectMaterial();
        equipment.selectPlastic();
        String itemsNumber = equipment.checkItemsNumber();
        anAssert.assertEquals(itemsNumber,"7 Items");
        equipment.sortBy();
        scrollDown1(700);
        equipment.addFirstProduct();
        equipment.selectAnotherCategory();


        JacketPage jackets = new JacketPage(driver,wait,anAssert);
        jackets.addSecondProduct();
        jackets.enterCart();


        CartPage cart = new CartPage(driver,wait,anAssert);
        cart.viewCart();
        String firstProductName = cart.validateFirstProductName();
        anAssert.assertEquals(firstProductName,"Go-Get'r Pushup Grips");
        String firstProductPrice = cart.validateFirstPrice();
        anAssert.assertEquals(firstProductPrice,"$19.00");
        cart.changeInvalidQty();
        String errorQtyMessage = cart.verifyErrorQtyMessage();
        cart.changeQty();
        anAssert.assertEquals(errorQtyMessage,"Please enter a number greater than 0 in this field.");
        scrollDown1(300);
        String secondProductName = cart.validateSecondProductName();
        anAssert.assertEquals(secondProductName,"Mars HeatTech™ Pullover");
        String secondProductPrice = cart.validateSecondProductPrice();
        anAssert.assertEquals(secondProductPrice,"$66.00");
        String itemOptions = cart.CheckItemOptions();
        anAssert.assertTrue(itemOptions.contains("S"));
        anAssert.assertTrue(itemOptions.contains("Black"));
        Thread.sleep(3000);
        scrollDown1(1000);
        Thread.sleep(3000);
        String flatRate = cart.checkFlatRate();
        anAssert.assertEquals(flatRate,"$20.00");
        String subtotal = cart.checkSubtotal();
        anAssert.assertEquals(subtotal,"$123.00");
        String shippingRate = cart.checkShippingRate();
        anAssert.assertEquals(shippingRate,"$20.00");
        String orderTotal = cart.checkOrderTotal();
        anAssert.assertEquals(orderTotal,"$143.00");
        cart.clickCheckout();

        ShippingPage shippingInformation = new ShippingPage(driver,wait,anAssert);
        boolean shippingInfo = shippingInformation.validateShippingAddress();
        anAssert.assertTrue(shippingInfo);
        String itemsQty = shippingInformation.checkItemsQty();
        anAssert.assertEquals(itemsQty,"4 Items in Cart");
        shippingInformation.clickItemsInCart();
        String product1Name = shippingInformation.validateFirstProductName();
        anAssert.assertEquals(product1Name,"Go-Get'r Pushup Grips");
        String product1Qty = shippingInformation.checkFirstProductQty();
        anAssert.assertEquals(product1Qty,"Qty 3");
        String product1Price = shippingInformation.checkFirstProductPrice();
        anAssert.assertEquals(product1Price,"$57.00");
        String product2Name = shippingInformation.validateSecondProductName();
        anAssert.assertEquals(product2Name,"Mars HeatTech™ Pullover");
        String product2Qty = shippingInformation.checkSecondProductQty();
        anAssert.assertEquals(product2Qty,"Qty 1");
        String product2Price = shippingInformation.checkSecondProductPrice();
        anAssert.assertEquals(product2Price,"$66.00");
        String rate = shippingInformation.checkFlatRate();
        anAssert.assertEquals(rate,"$20.00");
        shippingInformation.viewDetails();
        String size = shippingInformation.verifyProductSize();
        anAssert.assertEquals(size,"S");
        String color = shippingInformation.verifyProductColor();
        anAssert.assertEquals(color,"Black");
        shippingInformation.clickNextButton();

        ReviewAndPaymentPage review = new ReviewAndPaymentPage(driver,wait,anAssert);
        review.clickCheckbox();
        review.selectNewAddress();
        review.enterAddress("18 mile Road");
        review.enterCity("Rosemont");
        review.enterState();
        review.enterPostalCode("60018");
        review.enterCountry();
        review.enterPhone("+118642348890");
        review.clickSaveAddressCheckBox();
        Thread.sleep(2000);
        review.clickUpdate();
        boolean updatedAddress = review.validateUpdatedAddress();
        anAssert.assertTrue(updatedAddress,"The address is successfully updated");
        review.clickDiscountCode();
        review.enterDiscountCode("1000");
        review.applyButton();
        String message = review.validateDiscountMessage();
        anAssert.assertEquals(message,"The coupon code isn't valid. Verify the code and try again.");
        review.clickPlaceOrder();
        String confirmationMessage = review.validateOrderAcceptMessage();
        anAssert.assertEquals(confirmationMessage,"Thank you for your purchase!");
        anAssert.assertAll();



    }
}
