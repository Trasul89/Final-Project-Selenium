package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class BaseClass {

    public WebDriver driver;
    public WebDriverWait wait;
    public SoftAssert anAssert;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        anAssert = new SoftAssert();
    }

    public void scrollDown1(int pixels) {
        ((JavascriptExecutor) driver).executeScript("scroll(0," + pixels + ")");
    }

    @AfterMethod
    public void exit() {
        driver.quit();
    }
}
