package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class JacketPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By secondProduct = By.xpath("//li[@class='item product product-item'][5]");
    By addToCart = By.id("product-addtocart-button");

    public JacketPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public void addSecondProduct() {
        Actions actions = new Actions(driver);
        actions.click(driver.findElement(secondProduct)).perform();
        actions.click(driver.findElement(By.id("option-label-size-143-item-167"))).perform();
        actions.click(driver.findElement(By.id("option-label-color-93-item-49"))).perform();
    }

    public void enterCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCart)).click();
    }
}
