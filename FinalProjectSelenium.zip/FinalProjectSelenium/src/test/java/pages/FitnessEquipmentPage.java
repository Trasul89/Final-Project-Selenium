package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class FitnessEquipmentPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By category = By.xpath("//*[@id='narrow-by-list']/div[1]/div[1]");
    By exercise = By.xpath("//*[@id='narrow-by-list']/div[1]/div[2]/ol/li[2]/a");
    By material = By.xpath("//*[@id='narrow-by-list']/div[6]/div[1]");
    By plastic = By.xpath("//*[@id='narrow-by-list']/div[6]/div[2]/ol/li[4]/a");
    By number = By.id("toolbar-amount");
    By firstProduct = By.xpath("//li[@class='item product product-item'][5]");
    By addToCart = By.id("product-addtocart-button");
    By sortBy = By.id("sorter");


    public FitnessEquipmentPage(WebDriver driver, WebDriverWait wait, SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public void selectCategory() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(category)).click();
    }


    public void selectExercise() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(exercise)).click();
    }


    public void selectMaterial() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(material)).click();
    }


    public void selectPlastic() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(plastic)).click();
    }


    public String checkItemsNumber() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(number)).getText();
    }


    public void sortBy() {
        Select s = new Select(driver.findElement(sortBy));
        s.selectByValue("price");
    }


    public void addFirstProduct() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstProduct)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCart)).click();
    }


    public void selectAnotherCategory() {
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.id("ui-id-5"))).perform();
        actions.moveToElement(driver.findElement(By.id("ui-id-17"))).perform();
        actions.click(driver.findElement(By.id("ui-id-19"))).perform();
    }
}
