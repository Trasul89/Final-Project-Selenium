package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class CreateNewCustomerPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By pageTitle = By.xpath("//h1[@class='page-title']/span");
    By personalInfo = By.xpath("(//legend[@class='legend']/span)[1]");
    By signInInfo = By.xpath("(//legend[@class='legend']/span)[2]");
    By firstNameField = By.id("firstname");
    By lastNameField = By.id("lastname");
    By emailField = By.id("email_address");
    By passwordField = By.id("password");
    By confirmPasswordField = By.id("password-confirmation");
    By createAccountButton = By.xpath("(//button[@type='submit']/span)[2]");
    By firstNameError = By.id("firstname-error");
    By lastNameError = By.id("lastname-error");
    By emailError = By.id("email_address-error");
    By passwordError = By.id("password-error");
    By confirmPasswordError = By.id("password-confirmation-error");

    public CreateNewCustomerPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }

    public String validatePageTitle() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(pageTitle)).getText();
    }

    public String validatePersonalInfo() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(personalInfo)).getText();
    }

    public String validateSignInInfo() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(signInInfo)).getText();
    }

    public boolean verifyFirstNamePresence() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField)).getText();
        return true;
    }

    public void enterFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField)).sendKeys(firstName);
    }

    public boolean verifyLastNamePresence() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameField)).getText();
        return true;
    }

    public void enterLastName(String lastname) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameField)).sendKeys(lastname);
    }

    public boolean verifyEmailPresence() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailField)).getText();
        return true;
    }

    public void enterEmail(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailField)).sendKeys(email);
    }

    public boolean verifyPasswordPresence() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField)).getText();
        return true;
    }

    public void enterPassword(String password) {
         wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField)).sendKeys(password);
    }

    public boolean verifyConfirmPasswordPresence() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordField)).getText();
        return true;
    }

    public void enterConfirmPassword(String confirmPassword) {
         wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordField)).sendKeys(confirmPassword);
    }

    public void clickCreateButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createAccountButton)).click();
    }

    public String validateFirstNameErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameError)).getText();
    }

    public String validateLastNameErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameError)).getText();
    }

    public String validateEmailErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emailError)).getText();
    }

    public String validatePasswordErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(passwordError)).getText();
    }

    public String validateConfirmPasswordErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordError)).getText();
    }

    public String checkInvalidEmailFormat() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emailError)).getText();
    }

    public String checkAlreadyRegisterEmail() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='maincontent']/div[2]/div[2]/div/div/div"))).getText();
    }

    public String verifyPasswordCriteria() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(passwordError)).getText();
    }


    public String verifyPasswordStrength() {
      return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='password-strength-meter']"))).getText();
    }

    public String validateConfirmPassword() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordError)).getText();
    }

}
