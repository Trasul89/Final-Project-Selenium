package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class ProductPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By dropDown = By.xpath("//*[@id='ui-id-6']/span[2]");
    By selectDropDown = By.xpath("//*[@id='narrow-by-list2']/dd/ol/li[1]/a");
    By filter = By.xpath("//*[@id='narrow-by-list']/div[1]/div[1]");
    By selectFilter = By.xpath("//*[@id='narrow-by-list']/div[1]/div[2]/ol/li[5]/a/span");
    By selectFirstProduct = By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[3]/ol/li[3]/div/a/span/span/img");
    By firstProductName = By.xpath("//*[@id='maincontent']/div[2]/div/div[1]/div[1]/h1/span");
    By inStock = By.xpath("//*[@id='maincontent']/div[2]/div/div[1]/div[3]/div[2]/div[1]");
    By addProduct1ToCart = By.id("product-addtocart-button");
    By selectAnotherProduct = By.xpath("/html/body/div[2]/div[2]/ul/li[3]/a");
    By selectSecondProduct = By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[3]/ol/li[3]/div/div/strong/a");
    By secondProductName = By.xpath("//*[@id='maincontent']/div[2]/div/div[1]/div[1]/h1/span");
    By addProduct2ToCart = By.id("product-addtocart-button");
    By cart = By.xpath("//*[@id='maincontent']/div[1]/div[2]/div/div/div/a");
    By firstProductPrice = By.xpath("//*[@id='shopping-cart-table']/tbody[1]/tr[1]/td[2]/span/span/span");
    By secondProductPrice = By.xpath("//*[@id='shopping-cart-table']/tbody[2]/tr[1]/td[2]/span/span/span");
    By shippingAndTax = By.xpath("//*[@id='block-shipping-heading']");


    public ProductPage(WebDriver driver, WebDriverWait wait, SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public void productDropDown() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dropDown)).click();
    }


    public void selectFromDropdown() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectDropDown)).click();
    }


    public void clickFilter() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(filter)).click();
    }


    public void selectFilter() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectFilter)).click();
    }


    public void selectFirstProduct() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectFirstProduct)).click();
    }


    public String validateFirstProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductName)).getText();
    }


    public String verifyIfInStock() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(inStock)).getText();
    }


    public void addFirstProductToCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addProduct1ToCart)).click();
    }


    public void selectAnotherProduct() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectAnotherProduct)).click();
    }


    public void selectSecondProduct() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectSecondProduct)).click();
    }


    public String validateSecondProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductName)).getText();
    }


    public void addSecondProductToCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addProduct2ToCart)).click();
    }


    public void enterCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cart)).click();
    }


    public String validateFirstProductPrice() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductPrice)).getText();
    }


    public String validateSecondProductPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductPrice)).getText();
    }


    public void enterShippingAndTax() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shippingAndTax)).click();
    }


    public void setShippingDestination() {
        Select s = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/div[1]/div[2]/form[1]/fieldset/div[1]/div/select")));
        s.selectByValue("US");
        Select select = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/div[1]/div[2]/form[1]/fieldset/div[2]/div/select")));
        select.selectByValue("23");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/div[1]/div[2]/form[1]/fieldset/div[4]/div/input"))).sendKeys("60019");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='s_method_flatrate_flatrate']"))).click();
    }


    public String flatRate() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/div[2]/div/table/tbody/tr[2]"))).getText();
    }


    public String orderTotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/div[2]/div/table/tbody/tr[3]"))).getText();
    }


    public void checkout() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[1]/ul/li[1]/button/span"))).click();
    }


}
