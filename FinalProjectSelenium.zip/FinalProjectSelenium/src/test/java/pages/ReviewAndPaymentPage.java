package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class ReviewAndPaymentPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;


    public ReviewAndPaymentPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    By checkbox = By.xpath("(//input[@type='checkbox'])[2]");
    By selectNewAddress = By.xpath("(//select[@class='select'])[3]");
    By streetAddress = By.xpath("(//input[@name='street[0]'])[2]");
    By city = By.xpath("(//input[@name='city'])[2]");
    By state = By.xpath("(//select[@name='region_id'])[2]");
    By postalCode = By.xpath("(//input[@name='postcode'])[2]");
    By country = By.xpath("(//select[@class='select'])[5]");
    By phone = By.xpath("(//input[@name='telephone'])[2]");
    By saveAddressCheckBox = By.id("billing-save-in-address-book-checkmo");
    By update = By.xpath("//button[@class='action action-update']");
    By updatedAddress = By.cssSelector(".billing-address-details");
    By discountCode = By.xpath("//span[@id='block-discount-heading']");
    By enterDiscountCode = By.id("discount-code");
    By applyDiscountButton = By.xpath("//button[@value='Apply Discount']");
    By discountCodeMessage = By.xpath("//*[@id='co-payment-form']/fieldset/div[3]/div[2]/div/div/div");
    By placeOrder = By.xpath("//button[@title='Place Order']");
    By orderAcceptMessage = By.xpath("//span[text()='Thank you for your purchase!']");


    public void clickCheckbox() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkbox)).click();
    }


    public void selectNewAddress() {
        Select select = new Select(driver.findElement(selectNewAddress));
        select.selectByVisibleText("New Address");
    }


    public void enterAddress(String address) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(streetAddress)).sendKeys(address);
    }


    public void enterCity(String cityName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(city)).sendKeys(cityName);
    }


    public void enterState() {
        Select select = new Select(driver.findElement(state));
        select.selectByValue("23");
    }


    public void enterPostalCode(String zipCode) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(postalCode)).sendKeys(zipCode);
    }


    public void enterCountry() {
        Select select = new Select(driver.findElement(country));
        select.selectByValue("US");
    }


    public void enterPhone(String phoneNumber) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(phone)).sendKeys(phoneNumber);
    }


    public void clickSaveAddressCheckBox() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(saveAddressCheckBox)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(saveAddressCheckBox)).click();
    }


    public void clickUpdate() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(update)).click();
    }


    public boolean validateUpdatedAddress() {
        String firstName = "Ljubisha";
        String lastName = "Srbinovski";
        String city = "Rosemont";
        String state = "Illinois";
        String postalCode = "60018";
        String country = "United States";
        String homeAddress = "18 mile Road";
        String phone = "+118642348890";

        List<WebElement> shippingAddress = driver.findElements(updatedAddress);
        for (WebElement e : shippingAddress) {
            if (e.getText().contains(firstName) && e.getText().contains(lastName) && e.getText().contains(state) && e.getText().contains(city) && e.getText().contains(phone)
                    && e.getText().contains(postalCode) && e.getText().contains(country) && e.getText().contains(homeAddress)) {
                return true;
            }
        }
        return false;
    }




    public void clickDiscountCode() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(discountCode)).click();
    }


    public void enterDiscountCode(String code) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterDiscountCode)).sendKeys(code);
    }


    public void applyButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(applyDiscountButton)).click();
    }


    public String validateDiscountMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(discountCodeMessage)).getText();
    }


    public void clickPlaceOrder() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(placeOrder)).click();
    }


    public String validateOrderAcceptMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(orderAcceptMessage)).getText();
    }






















}
