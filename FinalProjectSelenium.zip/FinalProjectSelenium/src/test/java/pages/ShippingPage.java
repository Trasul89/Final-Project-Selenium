package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class ShippingPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By address = By.xpath("//div[@class='shipping-address-item selected-item']");
    By itemsInCart = By.xpath("//*[@class='block items-in-cart']");
    By firstProductName = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[1]/div/div/div/div[1]/strong");
    By firstProductQty = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[1]/div/div/div/div[1]/div");
    By firstProductPrice = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[1]/div/div/div/div[2]/span/span/span");
    By secondProductName = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[2]/div/div/div[1]/div[1]/strong");
    By secondProductQty = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[2]/div/div/div[1]/div[1]/div");
    By secondProductPrice = By.xpath("//*[@id='opc-sidebar']/div[1]/div/div[2]/div/ol/li[2]/div/div/div[1]/div[2]/span");
    By flatRate = By.xpath("//*[@class='price']/span");
    By viewDetails = By.xpath("//span[text()='View Details']");
    By size = By.xpath("//*[@class='values'][text()='S']");
    By color = By.xpath("//*[@class='values'][text()='Black']");
    By nextButton = By.xpath("//button[@data-role='opc-continue']");

    public ShippingPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public boolean validateShippingAddress() {
        String firstName = "Ljubisha";
        String lastName = "Srbinovski";
        String city = "Skopje";
        String postalCode = "1000";
        String country = "North Macedonia";
        String homeAddress = "ul.Dimitar Gushtanov 34/b";
        String phone = "072443770";

        List<WebElement> shippingAddress = driver.findElements(address);
        for (WebElement e : shippingAddress) {
            if (e.getText().contains(firstName) && e.getText().contains(lastName) && e.getText().contains(city) && e.getText().contains(phone)
                    && e.getText().contains(postalCode) && e.getText().contains(country) && e.getText().contains(homeAddress)) {
                return true;
            }
        }
        return false;
    }



    public String checkItemsQty() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(itemsInCart)).getText();
    }


    public void clickItemsInCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(itemsInCart)).click();
    }


    public String validateFirstProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductName)).getText();
    }


    public String checkFirstProductQty() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductQty)).getText();
    }


    public String checkFirstProductPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductPrice)).getText();
    }


    public String validateSecondProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductName)).getText();
    }


    public String checkSecondProductQty() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductQty)).getText();
    }


    public String checkSecondProductPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductPrice)).getText();
    }


    public String checkFlatRate() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(flatRate)).getText();
    }


    public void viewDetails() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(viewDetails)).click();
    }


    public String verifyProductSize() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(size)).getText();
    }


    public String verifyProductColor() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(color)).getText();
    }


    public void clickNextButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(nextButton)).click();
    }




















































































}
