package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class LumaHomePage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By createAnAccount = By.xpath("(//a[text()='Create an Account'])[1]");
    By createAnAccountButton = By.xpath("(//a[text()='Create an Account'])[1]");
    By signIn = By.xpath("(//li[@class='authorization-link']/a)[1]");
    By searchbox = By.xpath("//input[@id='search']");
    By searchboxOption = By.xpath("//ul[@role='listbox']/li[3]");
    By expectedSearchResults = By.xpath("//dl[@class='block']");
    By homepage = By.xpath("//a[@class='logo']/img");
    By homepageDropdown = By.xpath("//ul[@id='ui-id-2']");

    public LumaHomePage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public boolean homepageDropdown() {
        List<WebElement> dropdown = driver.findElements(homepageDropdown);
        for(WebElement e : dropdown) {
            if(e.getText().contains("What's New") && e.getText().contains("Women") && e.getText().contains("Men") &&
            e.getText().contains("Gear") && e.getText().contains("Training") && e.getText().contains("Sale")) {
                return true;
            }
        }
        return false;
    }


    public void searchBox(String product) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchbox)).sendKeys(product);
    }



    public void searchOptions() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchboxOption)).click();
    }


    public boolean expectedSearchResults() {
        List<WebElement> results = driver.findElements(expectedSearchResults);
        for (WebElement e : results) {
            if (e.getText().contains("watches")) {
                return true;
            }
        }
        return false;
    }


    public void backToHomePage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(homepage)).click();
    }


    public void validateCreateAnAccount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createAnAccount)).click();
    }


    public String createAnAccountButton() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(createAnAccountButton)).getText();
    }


    public void signIn() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signIn)).click();
    }


    public void dropDown() {
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//a[@id='ui-id-6']"))).perform();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Fitness Equipment']"))).click();
    }


}







