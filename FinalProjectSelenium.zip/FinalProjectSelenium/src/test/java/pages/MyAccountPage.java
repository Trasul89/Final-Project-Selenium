package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class MyAccountPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;


    By editAddress = By.xpath("//*[@id='maincontent']/div[2]/div[1]/div[4]/div[2]/div[1]/div[2]/a/span");
    By telephone = By.id("telephone");
    By address = By.id("street_1");
    By city = By.id("city");
    By country = By.id("country");
    By state = By.id("region");
    By zipCode = By.id("zip");
    By saveAddress = By.xpath("//button[@type='submit']/span[text()='Save Address']");
    By validation = By.xpath("//*[@class='message-success success message']/div");
    By logo = By.xpath("/html/body/div[2]/header/div[2]/a");
    By contactInfo = By.xpath("//*[@class='box-content']/p");



    public MyAccountPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }

    public String registrationValidation() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validation)).getText();
    }

    public String verifyContactInfo() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(contactInfo)).getText();
    }


    public void validateHomePageLogo() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(logo)).click();
    }


    public void editAddress() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(editAddress)).click();
    }


    public void enterTelephone(String phone) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(telephone)).sendKeys(phone);
    }


    public void enterAddress(String Address) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(address)).sendKeys(Address);
    }


    public void enterCity(String cityName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(city)).sendKeys(cityName);
    }


    public void setCountry() {
        Select select = new Select(driver.findElement(country));
        select.selectByValue("MK");
    }


        public void enterState(String stateName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(state)).sendKeys(stateName);
    }


    public void setZipCode(String postalCode) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(zipCode)).sendKeys(postalCode);
    }


    public void saveAddress() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(saveAddress)).click();
    }


}
