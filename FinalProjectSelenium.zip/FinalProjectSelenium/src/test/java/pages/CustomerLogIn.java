package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class CustomerLogIn {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By mail = By.id("email");
    By pass = By.id("pass");

    public CustomerLogIn(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;

    }

    public void enterEmail(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mail)).sendKeys(email);
    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pass)).sendKeys(password);
    }

}
