package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class CartPage {

    WebDriver driver;
    WebDriverWait wait;
    SoftAssert anAssert;

    By viewCart = By.xpath("//a[text()='shopping cart']");
    By firstProductName = By.xpath("(//strong[@class='product-item-name'])[3]/a");
    By price1 = By.xpath("//span[@class='cart-price']");
    By quantity = By.xpath("//div[@class='field qty']/div");
    By qtyMessage = By.xpath("//*[text()='Please enter a number greater than 0 in this field.']");
    By secondProductName = By.xpath("(//strong[@class='product-item-name'])[4]/a");
    By price2 = By.xpath("//span[@class='cart-price']//span[text()='$66.00']");
    By itemOptions = By.xpath("//dl[@class='item-options']");
    By checkout = By.xpath("//span[text()='Proceed to Checkout']");
    By flatRate = By.xpath("//span[@data-th='Shipping']");
    By subtotal = By.xpath("//td[@class='amount']/span[@data-th='Subtotal']");
    By shippingRate = By.xpath("//td[@class='amount']/span[@data-th='Shipping']");
    By orderTotal = By.xpath("//span[@class='price'][text()='$143.00']");



    public CartPage(WebDriver driver,WebDriverWait wait,SoftAssert anAssert) {
        this.driver = driver;
        this.wait = wait;
        this.anAssert = anAssert;
    }


    public void viewCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(viewCart)).click();
    }


    public String validateFirstProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductName)).getText();
    }


    public String validateFirstPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(price1)).getText();
    }


    public void changeInvalidQty() throws InterruptedException {
        WebElement e = wait.until(ExpectedConditions.elementToBeClickable(quantity));
        Actions actions = new Actions(driver);
        actions.click(e);
        actions.click(e);
        actions.sendKeys(Keys.BACK_SPACE);
        actions.sendKeys("-3");
        actions.sendKeys(Keys.ENTER);
        actions.perform();
    }


    public String verifyErrorQtyMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(qtyMessage)).getText();
    }


    public void changeQty() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(quantity));
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.BACK_SPACE);
        actions.sendKeys(Keys.BACK_SPACE);
        actions.sendKeys("3");
        actions.sendKeys(Keys.ENTER);
        actions.perform();
    }


    public String validateSecondProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductName)).getText();
    }


    public String validateSecondProductPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(price2)).getText();
    }


    public String CheckItemOptions() {
        String size = "S";
        String color = "Black";
        String itemsFalse = "itemsFalseInfo";
        List<WebElement> options = driver.findElements(itemOptions);
        for (WebElement e : options) {
            if (e.getText().contains(size) && e.getText().contains(color)) {
                return e.getText();
            }

        }
        return itemsFalse;
    }


    public String checkFlatRate() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(flatRate)).getText();
    }


    public String checkSubtotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(subtotal)).getText();
    }


    public String checkShippingRate() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(shippingRate)).getText();
    }


    public String checkOrderTotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(orderTotal)).getText();
    }


    public void clickCheckout() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkout)).click();
    }







}
